package com.crudexample.project.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.crudexample.project.model.Person;

@Service
public interface PersonService {
	
	
	public List<Person> getPersons();

}
