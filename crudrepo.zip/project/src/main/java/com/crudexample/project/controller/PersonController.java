
package com.crudexample.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.crudexample.project.model.Person;
import com.crudexample.project.service.PersonService;
import com.crudexample.project.service.impl.PersonServiceImpl;


@RestController
public class PersonController {
	
	@Autowired
	private PersonServiceImpl personService;
	
	@GetMapping("/getpersons")
	public List<Person> getPersonController(){
		return 	personService.getPersons();
	}
	
	
	@PostMapping("/addPerson")
	public Person addPersonController(@RequestBody Person person) {
		return personService.addPerson(person);
	}
}
