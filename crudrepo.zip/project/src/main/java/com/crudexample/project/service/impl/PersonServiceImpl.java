package com.crudexample.project.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.crudexample.project.model.Person;
import com.crudexample.project.repository.IPerson;
import com.crudexample.project.service.PersonService;

@Service
public class PersonServiceImpl implements PersonService{
	
	@Autowired
	IPerson iPerson;

	@Override
	public List<Person> getPersons() {
		// TODO Auto-generated method stub
		return iPerson.findAll();
	}

	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
		return iPerson.save(person);
		
	}

}
